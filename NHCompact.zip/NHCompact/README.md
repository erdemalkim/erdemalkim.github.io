# Implementation of NewHope-Compact
This package consist an implementation of NewHope-Compact key encapsulation scheme
that is optimized for CPU's with AVX2 extensions.

The code uses official [reference implementation](https://github.com/erdemalkim/NewHopeCompact) for NewHope-Compact.
As a result of the optimizations made for this project, poly.c and ntt.c are updated in addition to a new nttasm.S file.

## Assembly implementation of NTT and invNTT
NewHope-Compact assumes the coefficients of the polynomials arrenged in a way that NTT can be performed as parallel small NTTs.
The nttasm.S file consist to functions for size 128 NTT and invNTT, which they used 4, 6, and 8 times to perform NTT and invNTT 
for 511, 767, and 1023 degree polynomials, respectively.

Since AVX2 uses 256-bit vector registers, each vector register has 16 coefficients, which means that some layers of NTT transform should be
performed between coefficients in the same vector register. Hence coefficients should be reordered/shuffled to perform NTT layers where the processed coefficients has 
less than 16 distance to each other.

The NTT transformation implemented with using Cooley-Tukey butterflies and decimation-in-frequency method. Thus the last four layers should be performed 
between coefficients in the same vector register. To avoid the performance decrease, the implementation reorders the coefficients to be sure that all butterfly operations
are performed on the coefficients that are located on different vector registers. But the reference implementation has no such problem or reordering so the NTT transformation in
nttasm.S file, has some additional reordering just before storing the result. 

The inverse NTT transformation implemented with using Gentlemen-Sande butterflies and decimation-in-time method. Thus the reordering performed just after the coefficients loaded from memory.
Since the reordering in the begining of invNTT is inverse of the reordering in the end of the NTT transformation, removing those reorderings can be seen as a possible optimization to further speed up
the code. If this optimization used, one should also reorder the base multiplication rings accordingly.

The assembly optimized codes are also using some modular reduction optimizations from Kyber implementation. The tables, zetas, zetas\_exp and zetas\_inv\_exp, for the powers of the 2n-th root of unity have two different value for
each power. The first value is multiplication of inverse of q modulo R and the selected power of the 2n-th root of unity in montgomery domain. The second value is the selected power of the 2n-th root of unity in montgomery domain.
Since R=2^16, the first value can be used with vpmullw instruction to save one multiplication during montgomery reduction. But the reduction needs the most significant 16 bits of the original result should be calculated, and this can be done with using the second value and vpmulhw instruction.

The base multiplication is implemented with using intrinsic funtions to support all three implementations.

Generation of the polynomial a as well as the secret and error polynomials performed with using four way parallel shake function.

# Usage

Each directory includes their own Makefile, speed.c, test.c, api\_test.h, cpucycles.c, cpucycles.h, randombytes.c, and randombytes.h files. This files created only for texting and benchmarking the code. For 
supercop integration those files should be removed from directories.

All main directories named with the degree of the ring used in the scheme and codes are organized in avx2 directory to point out that codes optimized for this extension. 
The ´´make'' command can compile test\_kemXXX and speed\_kemXXX, where XXX is the degree of the polynomial, executables in each avx2 directory.

The executable test\_kemXXX reports the ciphertext, public key, and secret key sizes if all tests are succesful, an error message otherwise.
The executable speed\_kemXXX reports cycle counts for selected functions like NTT and invNTT.

